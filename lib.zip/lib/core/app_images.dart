abstract class AppImages {

  static const String story3 = 'assets/images/story_3.png';
  static const String story2 = 'assets/images/story_2.jpg';
  static const String myProfile = 'assets/images/story_1.jpg';
  static const String postProfile = 'assets/images/profile.jpg';
  static const String story2Profile = 'assets/images/profile_story_2.jpg';
  static const String story3Profile = 'assets/images/profile_story_3.jpg';
  static const String post = 'assets/images/post.jpg';
  static const String facebookLogo = 'assets/images/logo_facebook.png';
  static const String metaLogo = 'assets/images/meta_logo.png';
  static const String metaFromLogo = 'assets/images/meta.png';
  static const String subtractLogo = 'assets/icons/subtract.png';
  static const String addLogo = 'assets/icons/Plus.jpg';
  static const String searchLogo = 'assets/icons/Search.jpg';
  static const String messageLogo = 'assets/icons/Messenger.jpg';
  static const String photoLogo = 'assets/icons/Photos_icon.jpg';


}