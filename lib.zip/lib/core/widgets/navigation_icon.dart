
import 'package:face_book/core/app_colors.dart';
import 'package:flutter/material.dart';

Widget navigationIcon(IconData icon, bool isSelected) {
  return Icon(
    icon,
    size: 22,
    color: isSelected ? AppColors.blue : AppColors.gray,
  );
}