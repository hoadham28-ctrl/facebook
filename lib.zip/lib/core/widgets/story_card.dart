import 'package:flutter/material.dart';

import '../app_colors.dart';

Widget storyCard(String name, String storyImage, String profileImage) {
  return Container(
    width: 112,
    height: 178,
    margin: const EdgeInsets.only(right: 8),
    child: ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            storyImage,
            fit: BoxFit.cover,
          ),

          Positioned(
            top: 8,
            left: 8,
            child: Container(
              padding: const EdgeInsets.all(2),
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.blue,
              ),
              child: CircleAvatar(
                radius: 19,
                backgroundColor: AppColors.white,
                backgroundImage: AssetImage(profileImage),
              ),
            ),
          ),

          Positioned(
            bottom: 8,
            left: 8,
            child: Text(
              name,
              style: const TextStyle(
                color: AppColors.white,
                fontWeight: FontWeight.bold,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    ),
  );
}