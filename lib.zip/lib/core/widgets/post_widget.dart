import 'package:flutter/material.dart';

import '../app_colors.dart';
import '../app_images.dart';

Widget postWidget() {
  return Container(
    color: AppColors.white,
    padding: const EdgeInsets.only(left: 12, right: 12, top: 10),
    child: Column(
      children: [

        Row(
          children: [
            const CircleAvatar(
              radius: 20,
              backgroundColor: AppColors.blue,
              backgroundImage: AssetImage(AppImages.postProfile),
            ),

            const SizedBox(width: 8),

            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Route',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
                ),

                SizedBox(height: 3),

                Text(
                  '8 h · 🌐',
                  style: TextStyle(color: AppColors.gray, fontSize: 10),
                ),
              ],
            ),

            const Spacer(),

            const Icon(Icons.more_horiz, size: 22),
          ],
        ),

        const SizedBox(height: 10),

        Image.asset(
          AppImages.post,
          width: double.infinity,
          height: 230,
          fit: BoxFit.contain,
        ),

        const SizedBox(height: 10),

        Row(
          children: [
            const Icon(Icons.favorite_border, size: 19),

            const SizedBox(width: 10),

            const Icon(Icons.chat_bubble_outline, size: 19),

            const SizedBox(width: 10),

            const Icon(Icons.send_outlined, size: 19),

            const Spacer(),

            const Icon(Icons.bookmark_border, size: 20),
          ],
        ),

        const SizedBox(height: 10),
      ],
    ),
  );
}
