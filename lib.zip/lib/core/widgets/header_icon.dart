
import 'package:flutter/material.dart';

Widget headerIcon(IconData icon, {double size = 22}) {
  return Padding(
    padding: const EdgeInsets.only(left: 12),
    child: Icon(icon, size: size, color: Colors.black),
  );
}