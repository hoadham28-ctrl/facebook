import 'package:flutter/material.dart';
import '../app_colors.dart';
import '../app_images.dart';

Widget createStory() {
  return Container(
    width: 112,
    height: 178,
    margin: const EdgeInsets.only(right: 8),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(12),
      color: Colors.grey[300],
    ),
    child: ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            AppImages.myProfile,
            fit: BoxFit.cover,
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              height: 65,
              color: AppColors.white,
              child: Column(
                children: [
                  const CircleAvatar(
                    radius: 18,
                    backgroundColor: AppColors.blue,
                    child: Icon(Icons.add, color: AppColors.white),
                  ),
                  const Text(
                    'Create Story',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    ),
  );
}