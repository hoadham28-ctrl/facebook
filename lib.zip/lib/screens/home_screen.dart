import 'package:flutter/material.dart';

import '../core/app_colors.dart';
import '../core/app_images.dart';
import '../core/widgets/create_story.dart';
import '../core/widgets/navigation_icon.dart';
import '../core/widgets/post_widget.dart';
import '../core/widgets/story_card.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.only(top: 25, left: 12, right: 12),
                child: Row(
                  children: [
                    const Text(
                      'Facebook',
                      style: TextStyle(
                        color: AppColors.blue,
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Spacer(),
                    Image.asset(AppImages.addLogo, width: 26, height: 26),
                    const SizedBox(width: 12),
                    Image.asset(AppImages.searchLogo, width: 22, height: 22),
                    const SizedBox(width: 12),
                    Image.asset(AppImages.messageLogo, width: 22, height: 22),
                  ],
                ),
              ),
            ),

            SliverToBoxAdapter(
              child: SizedBox(
                height: 42,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    navigationIcon(Icons.home, true),
                    navigationIcon(Icons.ondemand_video, false),
                    navigationIcon(Icons.storefront, false),
                    navigationIcon(Icons.account_circle_outlined, false),
                    navigationIcon(Icons.notifications_none, false),
                    const CircleAvatar(
                      radius: 12,
                      backgroundImage: AssetImage(AppImages.myProfile),
                    ),
                  ],
                ),
              ),
            ),

            const SliverToBoxAdapter(child: Divider(height: 1)),

            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 11,
                  vertical: 18,
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 16,
                      backgroundImage: AssetImage(AppImages.myProfile),
                    ),
                    const SizedBox(width: 8),
                    const Expanded(
                      child: Text(
                        "What's in Your Mind?",
                        style: TextStyle(color: AppColors.gray, fontSize: 16),
                      ),
                    ),
                    Image.asset(AppImages.photoLogo, width: 28, height: 28),
                  ],
                ),
              ),
            ),

            const SliverToBoxAdapter(child: Divider(height: 1)),

            SliverToBoxAdapter(
              child: SizedBox(
                height: 178,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 10,
                  ),
                  children: [
                    createStory(),
                    storyCard('Ahmed', AppImages.postProfile, AppImages.story2),
                    storyCard(
                      'Mohamed',
                      AppImages.story2Profile,
                      AppImages.story3,
                    ),
                    storyCard(
                      'Ali',
                      AppImages.story3Profile,
                      AppImages.postProfile,
                    ),
                  ],
                ),
              ),
            ),

            const SliverToBoxAdapter(child: Divider(height: 5)),

            SliverToBoxAdapter(child: postWidget()),
          ],
        ),
      ),
    );
  }
}
