import 'package:flutter/material.dart';
import '../core/app_colors.dart';
import '../core/app_images.dart';
import 'login_screen.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
     Future.delayed(const Duration(seconds: 5), () {
      Navigator.pushReplacement(
         context,
         MaterialPageRoute(
           builder: (context) => const LoginScreen(),
         ),
       );
     });

    return
      Scaffold(
        backgroundColor: AppColors.white,
        body: Center(
          child: Padding(
            padding: const EdgeInsets.only(top: 294 ,bottom: 36),
            child: Column(

              children: [
                Image.asset(AppImages.facebookLogo ,width: 100,height: 100),
                Spacer(),
                Image.asset(AppImages.metaFromLogo ,width: 98,height: 59),

              ],
            ),
          ),
        ),
      );
  }
}


